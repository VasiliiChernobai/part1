package ua.nure.chernobai.Practice6.part1;

import java.util.*;
import java.util.regex.Pattern;

public class WordContainer {
	
	private TreeSet<Word> wordContainer;
	
	public WordContainer() {
		wordContainer  = new TreeSet<Word>();		
	}
	
	void setWord(String inString) {
		String[] str = Pattern.compile(" ").split(inString);	//Split input string into separate words 		
		HashSet<String> hash = new HashSet<String>(Arrays.asList(str));	//Check for unique elements				
		for (String  hs : hash) {
			if (!hs.isEmpty()) {	//Check for empty elements 				
				Word w = new Word(hs);											//Fill 
				w.setFrequency(Collections.frequency(Arrays.asList(str), hs));	//the container
				wordContainer.add(w);											//with input Words
			}
		}		
	}

	@Override
	public String toString() {
		String s = "";
		for (Word x : wordContainer.descendingSet()) {
			s += x + "\n";			//Realize the needed output in container
		}
		return s;
    }
	
}