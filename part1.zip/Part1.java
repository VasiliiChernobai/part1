package ua.nure.chernobai.Practice6.part1;

public class Part1 {
	
	public final static String inText = "asd asd  asdf asd asdf asdf 43 asdsf 43 43 434";

	public static void main(String[] args) {	
		WordContainer wc = new WordContainer();
		wc.setWord(inText);
		System.out.println(wc);
	}
}
